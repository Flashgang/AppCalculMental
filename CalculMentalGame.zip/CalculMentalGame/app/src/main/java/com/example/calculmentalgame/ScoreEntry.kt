package com.example.calculmentalgame

data class ScoreEntry(val pseudo: String, val score: Int)
